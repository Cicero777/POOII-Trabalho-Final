packPOOII
==============

#### Pacote utilizado para fazer alterações em arquivos de texto. 

## Instalação:

```
pip install packPOOII
```

## Como usar:

```
from packPOOII import packPOOII
s = packPOOII.PackPOOII()
s.subString(palavra)

```
